from django import forms
from .models import IceCream

class IceCreamForms(forms.ModelForm):
    class Meta:
        model=IceCream
        fields='__all__'
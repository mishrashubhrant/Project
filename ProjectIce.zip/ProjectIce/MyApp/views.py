from django.shortcuts import render,redirect,get_object_or_404
from .models import IceCream
from .forms import IceCreamForms
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login,logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test

def home_page(request):
    return render(request, 'index.html')

def about_page(request):
    return render(request, 'about.html')

def contact_page(request):
    return render(request, 'contact.html')

def menu_page(request):
    icecreams = IceCream.objects.all()  # Get all ice creams
    categories = IceCream.objects.values_list('category', flat=True).distinct()  # Get distinct categories
    
    return render(request, 'menu.html', {
        'icecreams': icecreams,
        'categories': categories,
    })


def is_staff_user(user):
    return user.is_staff

def login_page(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        if not username or not password:
            messages.error(request, "Please provide both username and password.")
            return render(request, 'login.html')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            messages.success(request, f"Welcome back, {user.username}!")
            return redirect('home') # Redirect to home page after login
        else:
            messages.error(request, "Invalid username or password.")

    return render(request, 'login.html')


def logout_view(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect('login')

def signup_page(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        phone = request.POST['phone']
        password = request.POST['password']

        if not username or not email or not phone or not password:
            messages.error(request, "Please fill in all fields.")
            return render(request, 'signup.html')

        

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
            return render(request, 'signup.html')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered.")
            return render(request, 'signup.html')

        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()
        messages.success(request, "Signup successful! You can now log in.")
        return redirect('login')

    return render(request, 'signup.html')

@user_passes_test(is_staff_user, login_url='login')
@login_required(login_url='login')
def add_icecream(request):
    if request.method == "POST":
        form = IceCreamForms(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect("menu")
    else:
        form = IceCreamForms()
    
    return render(request,'addicecream.html',{'form':form})

@user_passes_test(is_staff_user, login_url='login')
@login_required(login_url='login')
def admin_dashboard(request):
     icecreams = IceCream.objects.all()
     return render(request,'adminpage.html',{'data':icecreams})

@user_passes_test(is_staff_user, login_url='login')
@login_required(login_url='login')
def delete(request,id):
    item = get_object_or_404(IceCream,id=id)
    if request.method == "POST":
        item.delete()
        return redirect("adminpage")
    return render(request,'delete.html',{'item':item})

@user_passes_test(is_staff_user, login_url='login')
@login_required(login_url='login')
def update(request,id):
    item = get_object_or_404(IceCream,id=id)
    if request.method == "POST":
        form = IceCreamForms(request.POST, request.FILES, instance=item)
        if form.is_valid():
            form.save()
            return redirect("adminpage")
    else:
            form = IceCreamForms(instance=item)
    return render(request,'addicecream.html',{'form':form})
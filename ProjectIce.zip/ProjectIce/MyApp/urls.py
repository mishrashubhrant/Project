from django.urls import path
from .views import home_page, about_page, contact_page, menu_page, login_page, signup_page, add_icecream, admin_dashboard,update,delete
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path('', home_page, name='home'),
    path('about/', about_page, name='our_story'),
    path('contact/', contact_page, name='contact_us'),
    path('menu/', menu_page, name='menu'),
    path('login/', login_page, name='login'),
    path('signup/', signup_page, name='signup'),
    path('add/',add_icecream,name='add_icecream'),
    path('adminpage/',admin_dashboard,name='adminpage'),
    path('update/<int:id>',update,name="update"),
    path('delete/<int:id>',delete,name="delete"),
    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),
]
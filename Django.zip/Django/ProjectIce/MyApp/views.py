from django.shortcuts import render
from django.http import HttpResponse
from .models import IceCream
# Create your views here.

def home_page(request):
    return render(request, 'index.html')

def about_page(request):
    return render(request, 'about.html')

def contact_page(request):
    return render(request, 'contact.html')

def menu_page(request):
    icecreams = IceCream.objects.all()  # Get all ice creams
    categories = IceCream.objects.values_list('category', flat=True).distinct()  # Get distinct categories
    
    return render(request, 'menu.html', {
        'icecreams': icecreams,
        'categories': categories,
    })

def login_page(request):
    return render(request, 'login.html')

def signup_page(request):
    return render(request, 'signup.html')

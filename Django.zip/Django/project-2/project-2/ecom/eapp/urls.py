from django.urls import path
from .views import index,HomePage,adminpage,delete,update
urlpatterns = [
    path('',HomePage,name="homepage"),
    path('addproduct/',index,name='addproduct'),
    path('adminpage/',adminpage,name="adminpage"),
    path('update/<int:id>',update,name='update'),
    path('delete/<int:id>',delete,name='delete')
]

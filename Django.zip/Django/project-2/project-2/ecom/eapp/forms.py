from django import forms
from .models import Addproduct

class AddproductForms(forms.ModelForm):
    class Meta:
        model = Addproduct
        fields ='__all__'



from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import IceCream
from .forms import IceCreamForms
# Create your views here.

def home_page(request):
    return render(request, 'index.html')

def about_page(request):
    return render(request, 'about.html')

def contact_page(request):
    return render(request, 'contact.html')

def menu_page(request):
    icecreams = IceCream.objects.all()  # Get all ice creams
    categories = IceCream.objects.values_list('category', flat=True).distinct()  # Get distinct categories
    
    return render(request, 'menu.html', {
        'icecreams': icecreams,
        'categories': categories,
    })

def login_page(request):
    return render(request, 'login.html')

def signup_page(request):
    return render(request, 'signup.html')

def add_icecream(request):
    if request.method == "POST":
        form = IceCreamForms(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect("menu_page")
    else:
        form = IceCreamForms()
    
    return render(request,'addicecream.html',{'form':form})

def admin_dashboard(request):
     icecreams = IceCream.objects.all()
     return render(request,'adminpage.html',{'data':icecreams})
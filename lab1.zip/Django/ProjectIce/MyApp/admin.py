from django.contrib import admin
from .models import IceCream

admin.site.register(IceCream)
